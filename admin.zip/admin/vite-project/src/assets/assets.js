import logo from './logo.png';
import  download from './download.png'



export const assets = {
    logo,
    download
}